//
//  ProfileHeaderView.swift
//  Navigation
//
//  Created by Tatiana Volova on 01.11.2021.
//

import Foundation

class ProfileHeaderView: UIView {
    let view = UIView()
    
}
