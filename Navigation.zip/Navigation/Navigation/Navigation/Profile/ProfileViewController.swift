//
//  ProfileViewController.swift
//  Navigation
//
//  Created by Tatiana Volova on 02.11.2021.
//

import Foundation

class ProfileViewController: UIViewcontroller {

        override func viewDidLoad() {
            super.viewDidLoad()
            self.title = "Profile"
            self.view.backgroundColor = .lightGray
        }
}
