//
//  Post.swift
//  Navigation
//
//  Created by Tatiana Volova on 25.10.2021.
//

import Foundation

struct Post {
    var title: String
}
